// const db = require('.../modles');
// const { company_master } = db;
// const { Op } = require('sequelize');


// const CompanyNameById = async (id) => {
//     let company = await company_master.findByPk(id);
//     console.log(company)
// }


// const data = await Project.findOne({ 
//     where: { title: 'My Title' }, 
//     attributes:['id,name,getvendorname(vendor_id)']
// });

// data.
// if (project === null) {
//   console.log('Not found!');
// } else {
//   console.log(project instanceof Project); // true
//   console.log(project.title); // 'My Title'
// }