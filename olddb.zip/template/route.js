// Import express and the controller
import express from 'express';
import SomeController from '../controllers/SomeController';

const router = express.Router();

// Define routes and associate them with controller methods

/**
 * @route GET /items
 * @desc Get all items
 * @access Public
 */
router.get('/items', SomeController.getItems);

/**
 * @route GET /items/:id
 * @desc Get a single item by ID
 * @access Public
 */
router.get('/items/:id', SomeController.getItemById);

/**
 * @route POST /items
 * @desc Create a new item
 * @access Public
 */
router.post('/items', SomeController.createItem);

/**
 * @route PUT /items/:id
 * @desc Update an existing item by ID
 * @access Public
 */
router.put('/items/:id', SomeController.updateItem);

/**
 * @route DELETE /items/:id
 * @desc Delete an item by ID
 * @access Public
 */
router.delete('/items/:id', SomeController.deleteItem);

export default router;
